---
name: Bug report
about: Something is not working as expected
labels: bug
---

**What happened?**

**Steps to reproduce**
1.
2.

**Expected behaviour**

**Environment** (OS, Python version, storage format)

**Relevant log lines** (`logs/sis.log`)
